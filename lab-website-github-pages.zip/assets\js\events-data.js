// Update this list whenever you want to add, remove, or edit lab news and events.
// Use dates in YYYY-MM-DD format so the website can sort upcoming and past items.
window.labEvents = [
  {
    date: "2026-09-10",
    type: "Seminar",
    title: "Lab Seminar: Trustworthy AI for Scientific Discovery",
    description: "A public seminar introducing current projects and opportunities for collaboration.",
    link: "#"
  },
  {
    date: "2026-08-20",
    type: "Deadline",
    title: "Graduate Research Assistant Applications Due",
    description: "Prospective PhD and MS students should contact the PI with a CV and brief research statement.",
    link: "mailto:professor@university.edu?subject=Graduate%20Research%20Assistant%20Application"
  },
  {
    date: "2026-05-12",
    type: "Publication",
    title: "New Paper Accepted at JMLR",
    description: "Our work on calibrated uncertainty estimates for scientific foundation models has been accepted.",
    link: "#publications"
  },
  {
    date: "2026-04-18",
    type: "Award",
    title: "Lab Receives Interdisciplinary Research Grant",
    description: "The project will support new collaborations in computational policy and responsible machine learning.",
    link: "#research"
  }
];
