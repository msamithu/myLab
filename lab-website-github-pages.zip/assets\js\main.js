const header = document.querySelector("[data-header]");
const navToggle = document.querySelector(".nav-toggle");
const navLinks = document.querySelectorAll(".site-nav a");
const filterButtons = document.querySelectorAll("[data-filter]");
const publications = document.querySelectorAll(".publication-item");
const upcomingEvents = document.querySelector('[data-events="upcoming"]');
const pastEvents = document.querySelector('[data-events="past"]');

function syncHeader() {
  header.classList.toggle("is-scrolled", window.scrollY > 12);
}

syncHeader();
window.addEventListener("scroll", syncHeader, { passive: true });

navToggle.addEventListener("click", () => {
  const isOpen = header.classList.toggle("is-open");
  navToggle.setAttribute("aria-expanded", String(isOpen));
});

navLinks.forEach((link) => {
  link.addEventListener("click", () => {
    header.classList.remove("is-open");
    navToggle.setAttribute("aria-expanded", "false");
  });
});

filterButtons.forEach((button) => {
  button.addEventListener("click", () => {
    const filter = button.dataset.filter;

    filterButtons.forEach((item) => item.classList.toggle("is-active", item === button));
    publications.forEach((publication) => {
      const shouldShow = filter === "all" || publication.dataset.category === filter;
      publication.classList.toggle("is-hidden", !shouldShow);
    });
  });
});

function formatEventDate(dateString) {
  const date = new Date(`${dateString}T12:00:00`);
  return new Intl.DateTimeFormat("en", {
    month: "short",
    day: "numeric",
    year: "numeric"
  }).format(date);
}

function createEventItem(event) {
  const item = document.createElement("article");
  item.className = "event-item";

  const link = event.link
    ? `<a href="${event.link}">${event.title}</a>`
    : `<span>${event.title}</span>`;

  item.innerHTML = `
    <p class="event-meta">${formatEventDate(event.date)} · ${event.type}</p>
    <h4>${link}</h4>
    <p>${event.description}</p>
  `;

  return item;
}

function renderEvents() {
  if (!upcomingEvents || !pastEvents || !window.labEvents) return;

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const sortedEvents = [...window.labEvents].sort((a, b) => new Date(a.date) - new Date(b.date));
  const upcoming = sortedEvents.filter((event) => new Date(`${event.date}T12:00:00`) >= today);
  const past = sortedEvents
    .filter((event) => new Date(`${event.date}T12:00:00`) < today)
    .reverse();

  upcomingEvents.replaceChildren(...upcoming.map(createEventItem));
  pastEvents.replaceChildren(...past.map(createEventItem));

  if (!upcoming.length) {
    upcomingEvents.innerHTML = '<p class="empty-state">No upcoming events posted yet.</p>';
  }

  if (!past.length) {
    pastEvents.innerHTML = '<p class="empty-state">No recent news posted yet.</p>';
  }
}

renderEvents();
